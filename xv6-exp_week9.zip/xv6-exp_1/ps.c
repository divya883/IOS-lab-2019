#include "types.h"

#include "user.h"

int ps()
{

cps();
exit();
}
